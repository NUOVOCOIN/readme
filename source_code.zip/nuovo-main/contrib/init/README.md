Sample configuration files for:

SystemD: nuovocoind.service
Upstart: nuovocoind.conf
OpenRC:  nuovocoind.openrc
         nuovocoind.openrcconf
CentOS:  nuovocoind.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
